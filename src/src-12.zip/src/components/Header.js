import React from 'react';
import { Plus, Loader2, ArrowLeft } from 'lucide-react';
import { useLogin } from '../hooks/useLogin';
import authService from '../services/authService';
import { useNavigate, useLocation } from 'react-router-dom';
import {withMinimumDelay} from "../utils/withDelay";

export const Header = ({ showCreateButton = false, onCreateClick, isCreatingBudget = false }) => {
    const { handleLogout } = useLogin();
    const [isLoggingOut, setIsLoggingOut] = React.useState(false);
    const userInfo = authService.getUserInfo();
    const navigate = useNavigate();
    const location = useLocation();
    const showBackButton = location.pathname !== '/dashboard';
    const [isNavigating, setIsNavigating] = React.useState(false);

    const onLogout = async () => {
        setIsLoggingOut(true);
        try {
            await handleLogout();
        } catch (error) {
            console.error('Logout failed:', error);
        }
        setIsLoggingOut(false);
    };

    const handleBack = async () => {
        const backButton = document.querySelector('.back-button');
        backButton?.classList.add('animate-spin');
        await withMinimumDelay(async () => {
            await navigate('/dashboard');
        }, 1000);
    };

    return (
        <div className="fixed top-0 left-0 right-0 bg-white z-10 shadow-lg">
            <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                    <div className="flex flex-col md:flex-row md:items-center gap-4">
                        <div className="flex items-center gap-4">
                            {showBackButton && (
                                <button
                                    onClick={handleBack}
                                    className="back-button text-gray-600 hover:text-gray-900 transition-all duration-500 transform hover:-translate-x-1"
                                >
                                    <ArrowLeft className="h-6 w-6" />
                                </button>
                            )}
                            <h1 className="text-3xl font-bold text-gray-900">Smarty Budget Tracker</h1>
                        </div>
                        <span className="text-sm text-gray-600">{userInfo?.sub}</span>
                    </div>
                    <div className="flex flex-col md:flex-row gap-4">
                        <button
                            onClick={onLogout}
                            disabled={isLoggingOut}
                            className="inline-flex items-center justify-center px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:bg-blue-300"
                        >
                            {isLoggingOut && <Loader2 size={16} className="mr-2 animate-spin"/>}
                            {isLoggingOut ? 'Logging out...' : 'Logout'}
                        </button>
                        {showCreateButton && (
                            <button
                                onClick={onCreateClick}
                                disabled={isCreatingBudget}
                                className="inline-flex items-center justify-center px-4 py-2 border border-transparent
            text-sm font-medium rounded-md shadow-sm text-white
            bg-indigo-600 hover:bg-indigo-700
            focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500
            transition-all duration-200
            disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                {isCreatingBudget ? (
                                    <>
                                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                        Creating...
                                    </>
                                ) : (
                                    <>Create New Budget</>
                                )}
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};